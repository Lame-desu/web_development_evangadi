function myMultiplier(x) {
  return 3 * x;
}

var result = myMultiplier(4);
// console.log(result);

module.exports.myMultiplier = myMultiplier;
