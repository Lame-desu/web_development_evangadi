function random() {
  return Math.random();
}

var randomNum = random();
console.log(randomNum);

module.exports.random = random;
